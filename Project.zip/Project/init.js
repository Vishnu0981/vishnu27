const mongoose = require('mongoose');
const Listing = require("./models/model.js")
const initdata = require("./data/data.js");

async function main()
{
   await mongoose.connect("mongodb://localhost:27017/ProjectDB")
}

main()
.then(()=>{
    console.log("connected");
}).catch(err=>{
    console.log(err)
})

const initDB = async ()=>{
    Listing.deleteMany();
    await Listing.insertMany(initdata.data);
    console.log("sample was saved");

};
initDB()